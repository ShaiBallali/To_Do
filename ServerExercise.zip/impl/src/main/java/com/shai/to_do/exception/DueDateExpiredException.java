package com.shai.to_do.exception;

public class DueDateExpiredException extends Exception{
    public DueDateExpiredException(String message) { super(message); }
}
