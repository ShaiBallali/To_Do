package com.shai.to_do.constants;

public class Status {
    public static final String PENDING = "PENDING";

    public static final String DONE = "DONE";

    public static final String LATE = "LATE";

    public static final String ALL = "ALL";
}
