package com.shai.to_do.exception;

public class TodoAlreadyExistsException extends Exception {
    public TodoAlreadyExistsException(String message) { super(message); }
}
