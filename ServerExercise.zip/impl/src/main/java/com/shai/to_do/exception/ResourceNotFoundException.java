package com.shai.to_do.exception;

public class ResourceNotFoundException extends Exception {
    public ResourceNotFoundException(String message) { super(message); }
}
