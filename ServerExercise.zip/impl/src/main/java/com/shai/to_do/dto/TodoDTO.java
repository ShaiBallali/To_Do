package com.shai.to_do.dto;

public record TodoDTO(String title, String content, Long dueDate) {}
