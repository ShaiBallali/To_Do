package com.shai.to_do.exception;

public class BadRequestException extends Exception {}
