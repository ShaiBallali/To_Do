package com.shai.to_do.constants;

public class SortBy {
    public static final String ID = "ID";

    public static final String DUE_DATE = "DUE_DATE";

    public static final String TITLE = "TITLE";
}
